
// move pages
function moveToIndex(){
    window.location.href = "index.html"
}
function moveToSignUp(){
    window.location.href = "signup.html"
}

function moveToProduct(){
    window.location.href = "products.html"
}

function moveToBuy(){
    window.location.href = "buy.html" 
}

// checking if the user in the DB 
async function loginChecking(newEmail,passwordSignIn){
    // sending the connection user details 
    let  details = [newEmail,passwordSignIn];
    const result = await fetch(`/checkUser`,{
        method: "post",
        headers:{
            accept: "application/json",
            "content-type":"application/json"
        },
        body: JSON.stringify(details)
    });
    const data = await result.json();
    
    //  checking if the user in the DB 
    if(data === true){
        moveToProduct();
    }else{
        console.log("ERROR: " + data); 
        window.alert("ERROR: user not defined")
    }
};

function validLogIn(){
    // send info to checking validation 
    const newEmail = document.getElementById("signInEmail").value 
    const password = document.getElementById("signInPassword").value 
    let result = checkValid(newEmail,password);
    if (result === true){
        loginChecking(newEmail,password);
    }
}

// making validation to the inputs 
function checkValid(newEmail,password){
    // valid inputs 
    if(newEmail.indexOf("@") >= 1 && password.length > 2){  
        return true;
    } else{
        window.alert("ERROR: make sure your information are valid")
    }
};

// checking if the email exist in the DB
async function checkIfTheEmailAvailable(){
    // get info from the DB
    const result = await fetch(`/emailUser`);
    const data = await result.json();
    // take info from the signUp page
    const newEmail = document.getElementById("signInEmail").value 
    flag = true ; 
    // loop for all the data from the DB
    await data.forEach((value,index) => { 
        if(value.email === newEmail){
            flag = false; 
        };
    });   

    if(flag === true){
        // add the user to the DB & return to the index page
        addUser();
        moveToIndex();
    }else{
        console.log("ERROR: " + data);
        window.alert("ERROR: the email exist in the DB")
    }
};

// adding user to the database
async function addUser(){
    const newName = document.getElementById("signInName").value 
    const newEmail = document.getElementById("signInEmail").value 
    const newPassword = document.getElementById("signInPassword").value 

    // making a validation of the inputs.
    let resultValid = checkValid(newEmail,newPassword);
    if(resultValid === true){
        const newUser ={
            name: newName ,
            email: newEmail, 
            password: newPassword
    };
    // sending request to add user to the DB 
    const result = await fetch(`/addUser`,{
        method: `post`,
        headers:{
            accept: `application/json`,
            "content-type": `application/json` 
        },
        body: JSON.stringify(newUser),  
    });
    const data = await result.json() ;

    }else{
        console.log("ERROR: " + data)
        window.alert(`ERROR: one or more details are wrong`);
    }
};

// add product to the html file 
let counterProduct = 0 ; 

async function crateProducts(){
    // takes product from DB
    const result = await fetch("/getProduct");
    const data = await result.json();
    const divElement = document.getElementById("visibleInvisible");
    // if have values on the data start the creating 
    if(data != undefined){
        data.forEach((element,index) => {
            // the button in side the div visible
            const button = document.createElement("button");
            counterProduct ++; 
            divElement.appendChild(button);
            button.id = `productValues${index}`;
            button.setAttribute("class",`button-product`);
            button.setAttribute("onclick",`addProductValue(${index})`);

            // crate the information from the DB
            const crateP1 = document.createElement(`p`);
            const crateP2 = document.createElement(`p`);

            crateP1.id =`product-name${index}`,`productValues${index}`; 
            crateP2.id =`product-price${index}`, `productValues${index}`;

            crateP1.setAttribute("class",`p-product`); 
            crateP2.setAttribute("class",`p-product`);

            // crating the element & give them ID
            crateP1.innerHTML = data[index].productName;
            crateP2.innerHTML = data[index].price;


            button.appendChild(crateP1);
            button.appendChild(crateP2);
        });
    };
};

// sort the div element by 
async function sortValueBy(){

    let sortBy = document.getElementById(`sortBy`).value;
    let productNameSortList = [];
    let productPriceSortList = [];

    // add to the list product
    if(sortBy === "sortName"){
        // sort the value by str (latter)
        for(let i =0 ; i < counterProduct; i++){
            let productNameSort = document.getElementById(`product-name${i}`).innerHTML; 
            productNameSortList.push(productNameSort);
        };
        // sorting the list
        productNameSortList.reverse();
        // sending to the server to bring the data sorted
        try{   
            const result = await fetch(`/findProductName`,{
            method: `post`,
            headers:{
                accept: `application/json`,
                "content-type": `application/json` 
            },            
            body: JSON.stringify(productNameSortList),
        });
        // send to another function to build the element
        const data = await result.json();
        sortTheProductOnTheHTML(data)

        }catch (err){
            if (err) {
                console.log(err)
                window.alert("something wrong try again letter")
            }
        };

    }else if (sortBy === "sortPrice"){
        // sorting by price 
        for(let i =0 ; i < counterProduct; i++){
            let productPriceSort = document.getElementById(`product-price${i}`).innerHTML; 
            productPriceSortList.push(productPriceSort);
        };
        productPriceSortList.reverse();
        // sending the list to the DB to bring back sorted
        try{   
            const result = await fetch(`/findProductPrice`,{
            method: `post`,
            headers:{
                accept: `application/json`,
                "content-type": `application/json` 
            },            
            body: JSON.stringify(productPriceSortList),
        });
        // sending the info to another func to build div
        const data = await result.json();
        sortTheProductOnTheHTML(data)

        }catch (err){
                if (err) {
                    console.log(err)
                    window.alert("ERROR: something wrong try again letter")
                }
            };
    }else{
        window.alert("ERROR: something wrong try again letter")
    }
};

// the elements sort builder 
async function sortTheProductOnTheHTML(data){
        // the div we want to send for him elements
        const divElement = document.getElementById("visibleInvisible");
        // remove all the element
        data.forEach((element,index) => {
            document.getElementById(`productValues${index}`).remove()

            // the button in side the div visible
            const button = document.createElement("button");
            divElement.appendChild(button);
            button.id = `productValues${index}`;
            button.setAttribute("class",`button-product`);
            button.setAttribute("onclick",`addProductValue(${index})`);


            // crate the information from the DB
            const crateP1 = document.createElement(`p`);
            const crateP2 = document.createElement(`p`);
     
            // crating the element & give them ID
            crateP1.innerHTML = data[index].productName;
            crateP2.innerHTML = data[index].price;

            crateP1.id =`product-name${index}`,`productValues${index}`; 
            crateP2.id =`product-price${index}`, `productValues${index}`; 

            crateP1.setAttribute("class",`p-product`); 
            crateP2.setAttribute("class",`p-product`);

            button.appendChild(crateP1);
            button.appendChild(crateP2);
        });
};

// create the buy.html page from here 
let productsNameBuy = [];

// taking the products from HTML tag & creating a lists 
function addProductValue(productNumber){
    // select the info of the product in lists
    let productName = document.getElementById(`product-name${productNumber}`).innerText; 
    productsNameBuy.push(productName);
};

// counting the values for the next page.
function buyButton(){
    let totalProduct =  productsNameBuy.length;
    let totalPrice = 0 ;

    for (let i=0 ; i < totalProduct ; i++ ){
        totalPrice +=  productsPriceBuy[i]
    }
    document.getElementById("showProduct").innerHTML = totalProduct ; 
    document.getElementById("showPrice12").innerHTML = totalProduct;
};

async function buyPage(){
    // sending the purchase to the server 
    try{
        const result = await fetch("/sendProduct",{
            method: `post`,
            headers:{
                accept: `application/json`,
                "content-type": `application/json` 
            },            
            body: JSON.stringify(productsNameBuy),
        });
        // move to the next page
        moveToBuy();
    }catch(err){
    if(err){
        console.log("ERROR: " + data)
        window.alert("ERROR: something wrong try again letter")
    }
}
};

async function showProduct(){
    let productsSum = 0 ;
    try {
        // bring back the list of the products
        const result = await fetch("/getProducts")
        const data =  await result.json()
        // sum all the product price
        for(let i = 0; i < data.length ; i++){
            productsSum += data[i].price
        };
        // show the result of the order
        document.getElementById("showProduct").innerHTML = data.length;
        document.getElementById("showPrice12").innerHTML = productsSum;

    } catch(err){
        if(err){
            console.log("ERROR:something wrong try again letter");
        }
    };
};


async function ApproveOrder(){
    // confirm the order when the user press on "Approve"
    try{
        const result = await fetch("/ApproveOrder",{
            method: "post",
            headers: {
                accept: `application/json`,
                "content-type": `application/json` 
            }
        });
        const data = await result.json()
        // log out the customer from the system 
        logOut(data);

    }catch(err){
        if(err){
            window.alert("ERROR:something wrong try again letter");
        }  
    }
};

async function logOut(userName){
    // sending request to clear the global var from the server.
    try{
        const result = await fetch("/logOut");
        window.alert(`Thank you for your purchase ${userName}`);
        // return to the index page for a new purchase 
        moveToIndex();
    }catch(err){
        if(err){
            console.log("ERROR:" + data);
        }  
    }
};
