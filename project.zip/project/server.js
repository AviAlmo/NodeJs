const express = require("express");
const app = express();
const mongoose = require(`mongoose`);

app.use("/",express.static(`public`));
app.use(express.json()); 

// GLOBAL VAR 
let onlineUser ; 
let productArray =[]; 

// crate the document type's 
const users = mongoose.Schema({
    name: String, 
    email: String,
    password: String,
}); 
let userModel ;

const orders = mongoose.Schema({
    user: String,
    productsList: Array, 
});
let orderModel;

const products = mongoose.Schema({
    productName: String,
    price: Number, 
});

let productsModel;
// connecting to the database
async function connectToDB(){
    try{
        await mongoose.connect(
            "mongodb+srv://avialmo4582002:pImzaRBBDlKBIGPl@avicluster0.ytqvnit.mongodb.net/order-project-DB"     
        ); 

        userModel = mongoose.model(`users`,users);
        orderModel = mongoose.model(`pending-orders`,orders);
        productsModel = mongoose.model(`products`,products);
    }catch (err) { 
        console.log("error" + err )
    }; 
};
connectToDB();

// check if the user in the db
app.post(`/checkUser`, async (req, res) =>{
    const filter = {
        email :req.body[0] , 
        password:req.body[1]
    };
    try{
        const userDetails = await userModel.findOne(filter);
        onlineUser = userDetails.name    
        res.json(true); 
    }catch(err){
        res.status(500).json({msg: "cant get any user"});
    }
});

app.get(`/validUser`, (req,res)=>{
    onlineUser = req.body
});

// need to do if the email exist in the db
app.get(`/emailUser`, async (req, res) =>{
    try{
        const emailUser = await userModel.find(); 
        res.json(emailUser); 
} catch(err){
    res.status(500).json({msg: "cant get email"});
}
});

// adding new user to the system
app.post(`/addUser`, async (req,res) => {
    try{
        const addUser = req.body ; 
        userModel.create(addUser);
    }catch (err){
        res.status(500).json({msg:"cant add user"});
    }
});


// take products from the DB and send to the script *The MAIN PAGE*(no sorting)
app.get("/getProduct", async (req,res)=>{
    try{
        const productDetails = await productsModel.find(); 
        res.json(productDetails); 
    }catch(err){
        res.status(500).json({msg:"cant find any product"})
    };
});

// find the product name and return him to the script 
app.post("/findProductName", async (req,res)=>{
    let arrayValueClass =[]; 
    try{
        for (let i = 0 ; i < req.body.length ; i++){
            const ProductName =  await productsModel.findOne({productName: req.body[i]}) 
            arrayValueClass.push(ProductName)
        }; 
        sendBack(arrayValueClass);
        
        async function sendBack(classList){
            res.json(classList)
        }
    }catch(err){
        res.status(500).json({msg:"cant find any product"})
    };
});

// find the product name and return him to the script 
app.post("/findProductPrice", async (req,res)=>{
    let arrayValueClass =[]; 
    try{
        for (let i = 0 ; i < req.body.length ; i++){
            const ProductPrice =  await productsModel.findOne({price: req.body[i]}) 
            arrayValueClass.push(ProductPrice)
        }; 
        sendBack(arrayValueClass);
        
        async function sendBack(classList){
            res.json(classList)
        }
    }catch(err){
        res.status(500).json({msg:"cant find any product"})
    };
});

app.post("/sendProduct", async(req,res)=>{
    productArray = req.body; 
    res.json()
});

let productPaddingArray = [];

app.get("/getProducts", async(req,res)=>{
   
    for (let i =0 ; i <  productArray.length ; i++){
        const productListBuy =  await productsModel.findOne({productName: productArray[i]});
        productPaddingArray.push(productListBuy);
    }; 
    res.json(productPaddingArray)
});

// adding new order 
app.post(`/ApproveOrder`, (req,res) => {
    try{
        const orderPending = {
            user: onlineUser,
            productsList: productArray
        }; 
        orderModel.create(orderPending);
        res.json(onlineUser);
    }catch (err){
        res.status(500).json({msg:"ERROR: something wrong cant add the order"});
    }
});

app.get("/logOut",(req,res)=>{
    onlineUser = "";
    productArray = [];
    res.json()
});


const port = 3000; 
app.listen(port);